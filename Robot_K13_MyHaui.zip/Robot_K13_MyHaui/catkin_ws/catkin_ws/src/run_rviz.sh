#!/bin/bash

#roslaunch mybot_description mybot_rviz.launch
roslaunch mybot_description mybot_rviz_amcl.launch 
