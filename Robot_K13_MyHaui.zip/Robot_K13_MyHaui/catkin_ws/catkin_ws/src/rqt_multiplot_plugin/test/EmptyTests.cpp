#include <gtest/gtest.h>

TEST(Placeholder, emptyTest) {  // NOLINT
  ASSERT_TRUE(true);
}
